# STARWARS

STEPS  TO START

1) NPM INSTALL
2) NPM START
3) Production : npm build:prod

Description:
This app describes details of planets of star wars
It contains 3 pages 
Login
username:Luke Skywakers
password:19BBY
HOME: It provides list of planets
Search:here you can search any planet

