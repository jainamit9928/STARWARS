import { API_URL } from '../constants/constants'
import fetchJsonp from 'fetch-jsonp'

export const getData = () => (
    new Promise(function(resolve, reject) {
        fetch(API_URL+"/?format=json",{
            headers: { 
                        "Accept" : "application/json; charset=utf-8",
                        "Content-Type": "application/json; charset=utf-8"
                        },
            crossdomain: true,})
        .then((response) => response.json())
        .then((res) => {
            const planets = res.results
            setTimeout(() => resolve(planets), 500)
        }).catch((error) => {
            reject(error);
        });
    })
)



export const getFilteredData = (id) => (
    new Promise(function(resolve, reject) {
        fetch(API_URL+'/?search='+id)
        .then((response) => response.json())
        .then((res) => {
            const planets = res.results
            console.log("in api id and planets",planets.length,id)
            resolve(planets)
        })
        .catch((error) => {
            reject(error);
        });
    })
)