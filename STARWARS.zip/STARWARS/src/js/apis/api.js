import { API_URL } from '../constants/constants'
import fetchJsonp from 'fetch-jsonp'

export const getData = () => (
    new Promise(function(resolve, reject) {
        fetch(API_URL,{
            headers: { 
                        "Accept" : "application/json; charset=utf-8",
                        "Content-Type": "application/json; charset=utf-8"
                        },
            crossdomain: true,})
        .then((response) => response.json())
        .then((res) => {
            const planets = res.results
            console.log("in api",planets.length)
            setTimeout(() => resolve(planets), 500)
        }).catch((error) => {
            reject(error);
        });
    })
)



