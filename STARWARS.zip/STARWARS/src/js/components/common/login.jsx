import React from 'react'
import ErrorComponent from './showerror'

class Login extends React.PureComponent {
    constructor(props) {
        super(props);
        this.onAuthorize = this.onAuthorize.bind(this);
        this.state = {
            hasError: false
        }
    }

    onAuthorize(e) {
        e.preventDefault();
        const username = this.username.value.trim()
        const password =this.password.value.trim()
        window.localStorage.setItem('username', JSON.stringify(username))
        window.localStorage.setItem('password', JSON.stringify(password))
        if (username.length > 0 && username.length > 0 ) {
            this.props.onClose()
            this.setState({ hasError: false })
            window.localStorage.setItem('status', JSON.stringify("login successfully"))
        }
        
        else {
            this.setState({ hasError: true })
        }
        console.log('username', );
    }




    render() {
        return (
            <div>
                <ErrorComponent className='error' wrongCredentials={ this.state.hasError } />
                
            <form className='form-horizontal col-md-8'>
                <div className='form-group'>
                    <label>Username:</label>
                    <div>
                         <input type="text" name="" id="" placeholder="username" className="user form-control" ref={(input) => { this.username = input; }} ></input>
                    </div>
                </div>
                <div className='form-group'>
                    <label >Password:</label>
                    <div>
                       <input type="password" name="" id="" placeholder="password" className="pass form-control" ref={(input) => { this.password = input; }} ></input>
                    </div>
                </div>
              
                <div className='input-group'>
                   <button className="btn btn-default" type="submit" onClick={ this.onAuthorize }>Login</button>
                </div>
            </form>
        </div>
       
        )
    }

}

export default Login;
