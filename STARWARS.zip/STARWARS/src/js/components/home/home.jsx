import React from 'react'
import Planet from '../common/planet'
import InputSearch from '../common/inputsearch'
import ErrorComponent from '../common/showerror'
import Modal from '../common/modal'
import Login from '../common/login'
import { LOADER_OPTIONS,LOGIN_HEADER } from '../../constants/constants'
import Loader from 'react-loader'
import PropTypes from 'prop-types'
import _ from 'lodash'
import { getVisiblePlanets } from '../../utils/utils'
export default class Home extends React.PureComponent {

    constructor(props) {
        super(props);
        this.state = {
            isModalOpen: true,
            hasError:false,
            searchedPlanets:[]
        }
        this.onOpenModal = this.onOpenModal.bind(this)
        this.onCloseModal = this.onCloseModal.bind(this)
        this.setSearchKey = this.setSearchKey.bind(this)

    }
    componentDidMount() {
        const status = JSON.parse(window.localStorage.getItem('status'))
        if(status == "login successfully"){
             this.setState({ isModalOpen: false })
        }
        this.props.actions.getDataRequest();
        this.props.actions.clearSearchKey();
    }
     onOpenModal() {
        this.setState({ isModalOpen: true})
    }
    onCloseModal() {
        this.setState({ isModalOpen: false })
        this.props.history.push('/');
    }
    setSearchKey(key){
        console.log("key",key)
        this.props.actions.setSearchKey(key)
        let searchedDetails = getVisiblePlanets(this.props.planets,key);
       this.setState({ searchedPlanets: searchedDetails })

        
    }
    render() {
    
            return ( 
            <div>    
            {
                this.state.isModalOpen ? (
                        <Modal header={ LOGIN_HEADER } isOpen={this.state.isModalOpen}  >
                                <Login  onClose={this.onCloseModal} />
                        </Modal> ) :
                        <PlanetDetails data={this.props} searchedData = { this.state.searchedPlanets } setSearchKey = { this.setSearchKey }/>
            }
        </div>
            )
         
    }
}

const PlanetDetails = (props) =>{
 const  {
            actions, 
            match, 
            errorMessage, 
            isFetching, 
            planets, 
            searchKey
        } = props.data
       
        const { setSearchKey, searchedData } = props
        const searchedPlanets = searchKey.length > 0 ? searchedData : planets
        console.log("searchedPlanets",searchedPlanets)

return (
    <Loader loaded={!isFetching} className='spinner' options={LOADER_OPTIONS}>
                <div className='component-block'>
                  
                        <InputSearch setSearchKey={ setSearchKey } searchKey={ searchKey } clearSearchKey={ actions.clearSearchKey } />
                    {searchedPlanets.length > 0 && (
                        <div className='col-md-12'>
                            
                            {
                                _.map(searchedPlanets, (planet) => (
                                    <Planet key={ planet.name } planet={ planet }/>
                                ))
                            }
                        </div>
                    )
                    }
                      {<ErrorComponent className='error'  noDataFound={ !searchedPlanets.length > 0 } />}
                </div>
            </Loader>
)

}

Home.propTypes = {
    actions: PropTypes.object.isRequired,
    errorMessage: PropTypes.string,
    planets: PropTypes.array.isRequired,
    searchKey: PropTypes.string.isRequired,
    isFetching: PropTypes.bool.isRequired,
};
