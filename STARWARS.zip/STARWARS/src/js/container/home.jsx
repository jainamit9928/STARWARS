import * as stateActions from '../actions/actions'
import { connect } from 'react-redux'
import Home from '../components/home/home'
import { bindActionCreators } from 'redux'

const mapStateToProps = (state, props) => {
    console.log("planets in home",state.planets.planets)
         return {
            planets:state.planets.planets,
            searchKey:state.search.searchKey,
            isFetching:state.planets.isFetching,
            errorMessage:state.planets.errorMessage,
        }
}
const mapDispatchToProps = (dispatch) => {
      return {
       actions:bindActionCreators(stateActions, dispatch),
    }
}
const HomeContainer =connect(mapStateToProps, mapDispatchToProps)(Home);
export default HomeContainer
