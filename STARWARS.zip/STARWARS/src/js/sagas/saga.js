import { call, put, takeEvery, all, take, race, select } from 'redux-saga/effects'
import * as actionTypes from '../constants/constants.js'
import { getData, getFilteredData } from '../apis/api'
import * as actions from '../actions/actions'
import 'regenerator-runtime/runtime'
import _ from 'lodash'
import { addToStorage } from '../utils/utils'

export function* fetchData() {
  try {
    const data = yield call(getData)
    yield put(actions.getDataSuccess(data))
  } catch (error) {
    yield put(actions.getDataFailure(error.message))
  }

}

export function* fetchFilteredData(action) {
  try {
    const data = yield call(getFilteredData, action.id)
    yield put(actions.getFilteredDataSuccess(data))
  } catch (error) {
    yield put(actions.getFilteredDataFailure(error.message))
  }
}




//backgroundTask
export function* watchAndLog() {
  while (true) {
    yield take('*')
    yield select()
  }
}

export function* watchStartBackgroundTask() {
  addToStorage()
  while (true) {
    yield take('*')
    yield race({
      task: call(watchAndLog),
      cancel: take('CANCEL_TASK'),
    })
  }
}

export function* watchFetchAsync() {
  yield takeEvery(actionTypes.GET_DATA_REQUEST, fetchData)
  yield takeEvery(actionTypes.GET_FILTERDDATA_REQUEST, fetchFilteredData)

}

export function* rootSaga() {
  yield all([watchFetchAsync(), watchStartBackgroundTask()])
}
