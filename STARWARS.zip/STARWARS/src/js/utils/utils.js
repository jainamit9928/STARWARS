import _ from 'lodash'


export const addToStorage = () => {
        let username = "Luke Skywalker"
        let password =  "19BBY"
        window.localStorage.setItem('username', JSON.stringify(username))
         window.localStorage.setItem('password', JSON.stringify(password))
}
export const getVisiblePlanets = (planets, param) => planets.filter((planets, index) => (planets.name.toLowerCase().includes(param)))