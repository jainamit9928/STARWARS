import _ from 'lodash'


export const addToStorage = () => {
        let totalHits = JSON.parse(window.localStorage.getItem('totalHits'))
        if(!(totalHits > 0)){
          totalHits = 0
        }
       
        window.localStorage.setItem('totalHits', JSON.stringify(totalHits))
}
export const getVisiblePlanets = (planets, param) => planets.filter((planets, index) => (planets.name.toLowerCase().includes(param)))